<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use \Illuminate\Support\Facades\Input;
use \App\Aid;


Route::get('/', function () {
    if (Auth::guest()) {
        return view('index');
    } else {
        return redirect('/home');
    }

});

Auth::routes();

Route::get('/dataset', 'DatasetController@index');
Route::get('/dataset/delete', 'DatasetController@destroy');
Route::post('/dataset/add', 'DatasetController@store');

Route::get('/prediction', function () {
    if (Auth::guest()) {
        return view('auth.login');
    } else {
        $precords = DB::table('datasets')
            ->select('population')
            ->groupBy('population')
            ->get();

        $rrecords = DB::table('datasets')
            ->select('avg_monsoon_rainfall')
            ->groupBy('avg_monsoon_rainfall')
            ->get();
        $drecords = DB::table('datasets')
            ->select('post_monsoon_water_level_depth')
            ->groupBy('post_monsoon_water_level_depth')
            ->get();

        return view('prediction', compact('precords', 'rrecords', 'drecords'));
    }
});
Route::get('/people', 'PeopleController@index');
Route::post('/people/add', 'PeopleController@store');
Route::get('/people/delete', 'PeopleController@destroy');
Route::get('/home', 'HomeController@index');


Route::get('/aid', 'AidController@index');
Route::post('/aid/allocate', 'AidController@allocate');
Route::get('/aid/get', 'AidController@get');







