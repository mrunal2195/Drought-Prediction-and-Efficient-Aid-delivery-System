@extends('layouts.app')





@section('content')




    <div class="mdl-card mdl-shadow--2dp" style="margin: 50px auto 50px auto;">


        <div class="mdl-card__supporting-text">

            <p>
            <h2 style="text-align:center" class="header">Fight Drought</h2>

            </p>
            <p>
            <h6 style="text-align:center">Create your free account</h6>
            </p>

            <form id="register_form" method="POST" action="{{ route('register') }}">
                {{ csrf_field() }}


                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"
                     style="width: 100%; margin-left: auto; margin-right: auto; display: block;">
                    <input class="mdl-textfield__input" name="name" type="text" id="name"
                           autofocus>
                    <label class="mdl-textfield__label" for="name">Name</label>
                </div>

                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"
                     style="width: 100%; margin-left: auto; margin-right: auto; display: block;">
                    <input class="mdl-textfield__input" name="email" value="{{ old('email') }}" type="email"
                           id="email">
                    <label class="mdl-textfield__label" for="email">Email</label>
                </div>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"
                     style="width: 100%; margin-left: auto; margin-right: auto; display: block;">
                    <input class="mdl-textfield__input" name="password" type="password" id="password">
                    <label class="mdl-textfield__label" for="password">Password</label>
                </div>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"
                     style="width: 100%; margin-left: auto; margin-right: auto; display: block;">
                    <input class="mdl-textfield__input" name="password_confirmation" type="password" id="cpassword">
                    <label class="mdl-textfield__label" for="cpassword">Confirm Password</label>
                </div>


            </form>

            @if (count($errors) > 0)


                @foreach ($errors->all() as $error)
                    <li style="color:red">{{ $error }}</li>
                @endforeach


            @endif

        </div>
        <div class="mdl-card__actions mdl-card--border">

            <a style="width: 80%; margin-left: auto; margin-right: auto; display: block;"
               onclick="document.getElementById('register_form').submit();"
               class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent   ">
                Create your free account
            </a>


        </div>
    </div>

@endsection
