@extends('layouts.app')


@section('content')




    <div class="mdl-card mdl-shadow--2dp" style="margin: 50px auto 50px auto;">


        <div class="mdl-card__supporting-text">

            <p>
            <h2 style="text-align:center" class="header">Fight Drought</h2>
            </p>
            <p>
            <h6 style="text-align:center">Login to your account</h6>
            </p>
            <form id="login_form" method="POST" action="{{ route('login') }}">
                {{ csrf_field() }}

                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"
                     style="width: 100%; margin-left: auto; margin-right: auto; display: block;">
                    <input class="mdl-textfield__input" name="email" type="text" value="{{ old('email') }}" id="email"

                           autofocus>
                    <label class="mdl-textfield__label" for="email">Email</label>
                </div>

                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"
                     style="width: 100%; margin-left: auto; margin-right: auto; display: block;">
                    <input class="mdl-textfield__input" name="password" type="password" id="password"
                    >
                    <label class="mdl-textfield__label" for="password">Password</label>
                </div>



                @if (count($errors) > 0)

                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>

                @endif


                <br>
                <br>

                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="remember">
                    <input type="checkbox" id="remember" class="mdl-checkbox__input"
                           name="remember" {{ old('remember') ? 'checked' : '' }}>
                    <span class="mdl-checkbox__label">Remember me</span>
                </label>

                <br>
                <br>

                <a style="width:100%; margin-left: auto; margin-right: auto; display: block;"

                   href="{{ route('password.request') }}">
                    Forgot Your Password?
                </a>


            </form>

        </div>
        <div class="mdl-card__actions mdl-card--border">


            <a style="width: 80%; margin-left: auto; margin-right: auto; display: block;"
               onclick="document.getElementById('login_form').submit();"
               class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent   ">
                Login
            </a>

            <br>

            <a style="width: 80%; margin-left: auto; margin-right: auto; display: block;" href="/register"
               class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
                Register
            </a>




        </div>






@endsection('content')