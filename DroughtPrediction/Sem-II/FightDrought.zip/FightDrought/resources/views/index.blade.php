@extends('layouts.app')

@section('content')


    <div style="text-align:center; color: #ffffff; background: url('../images/topbanner.jpg'); background-size: cover;">
        <br><br><br>
        <br><br><br>
        <h1 class="header center text-lighten-2">Let's fight drought!</h1>
        <h5 class="header col s12 light">We have to convert this crisis into opportunities and transform the present
            into a better future</h5>
        <br><br><br>
        <br><br><br>
    </div>




    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--4-col">
            <div>
                <h2 class="center brown-text"><i class="material-icons">flash_on</i></h2>
                <h5 class="center">Drought Prediction</h5>

                <p class="light">Drought Prediction using Naive Bayes Data Mining Algorithm helps to determine whether a
                    place will be affected by drought or not. It uses different parameters like population, average
                    monsoon rainfall and post monsoon water depth level</p>
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col">
            <div class="icon-block">
                <h2 class="center brown-text"><i class="material-icons">group</i></h2>
                <h5 class="center">Aid Allocation</h5>

                <p class="light">
                    Allocate the aid to the victims of drought. This allocation of aid is based on number of members in
                    the family.
                    Number
                    of adult and non adult members is also considered to make sure that significant amount of aid is
                    being
                    allocated.
                </p>
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col">
            <div class="icon-block">
                <h2 class="center brown-text"><i class="material-icons">settings</i></h2>
                <h5 class="center">Dataset Management</h5>

                <p class="light">
                    Manage the dataset which is being used for predicting the drought.
                    View all the records, add a new record or remove existing one without the knowledge of any query
                    language.
                </p>
            </div>
        </div>
    </div>



    <footer class="mdl-mega-footer">
        <div class="mdl-mega-footer__middle-section">

            <div class="mdl-mega-footer__drop-down-section">
                <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                <h1 class="mdl-mega-footer__heading">Features</h1>
                <ul class="mdl-mega-footer__link-list">
                    <li><a href="#">About</a></li>
                    <li><a href="#">Terms</a></li>
                    <li><a href="#">Partners</a></li>
                    <li><a href="#">Updates</a></li>
                </ul>
            </div>

            <div class="mdl-mega-footer__drop-down-section">
                <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                <h1 class="mdl-mega-footer__heading">Details</h1>
                <ul class="mdl-mega-footer__link-list">
                    <li><a href="#">Specs</a></li>
                    <li><a href="#">Tools</a></li>
                    <li><a href="#">Resources</a></li>
                </ul>
            </div>

            <div class="mdl-mega-footer__drop-down-section">
                <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                <h1 class="mdl-mega-footer__heading">Technology</h1>
                <ul class="mdl-mega-footer__link-list">
                    <li><a href="#">How it works</a></li>
                    <li><a href="#">Patterns</a></li>
                    <li><a href="#">Usage</a></li>
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Contracts</a></li>
                </ul>
            </div>

            <div class="mdl-mega-footer__drop-down-section">
                <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                <h1 class="mdl-mega-footer__heading">FAQ</h1>
                <ul class="mdl-mega-footer__link-list">
                    <li><a href="#">Questions</a></li>
                    <li><a href="#">Answers</a></li>
                    <li><a href="#">Contact us</a></li>
                </ul>
            </div>

        </div>

        <div class="mdl-mega-footer__bottom-section">
            <div class="mdl-logo">Title</div>
            <ul class="mdl-mega-footer__link-list">
                <li><a href="#">Help</a></li>
                <li><a href="#">Privacy & Terms</a></li>
            </ul>
        </div>

    </footer>

@endsection


