<?php $__env->startSection('content'); ?>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
        <header class="mdl-layout__header mdl-layout__header--scroll" style="background-color: #303F9F ">
            <div class="mdl-layout__header-row">
                <!-- Title -->
                <span class="mdl-layout-title">Aid Allocation</span>
                <!-- Add spacer, to align navigation to the right -->
                <div class="mdl-layout-spacer"></div>
                <!-- Navigation. We hide it in small screens.
                <nav class="mdl-navigation">
                    <a id="delete" class="mdl-navigation__link"><i
                                class="material-icons">delete</i></a>
                </nav>
                -->
            </div>
        </header>

        <main class="mdl-layout__content" style="background-color: #E8EAF6">
            <div class="page-content">
                <table class="mdl-data-table mdl-js-data-table mdl-data-table--selectable mdl-shadow--2dp"
                       style="margin: 50px auto 50px auto;">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th class="mdl-data-table__cell--non-numeric">Family Head Name</th>
                        <th>No. of units</th>
                        <th class="mdl-data-table__cell--non-numeric">Status</th>
                    </tr>
                    </thead>
                    <tbody id="table_body">
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->family_id); ?></td>
                            <td><?php echo e($record->headName); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->units); ?></td>
                            <?php if($record->units==0): ?>
                                <td>-</td>
                            <?php else: ?>
                                <td><?php echo e($record->deliveryStatus); ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <button id="show-dialog" style="position: fixed;
    display: block;
    right: 0;
    bottom: 0;
    margin-right: 40px;
    margin-bottom: 40px;
    z-index: 900;"
                    class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored">
                <i class="material-icons">add</i>
            </button>


            <dialog class="mdl-dialog" style="position:absolute;">
                <h4 class="mdl-dialog__title">Allocate Aid</h4>
                <div class="mdl-dialog__content">

                    <form id="allocate_form" action="/aid/allocate" method="POST">

                        <?php echo e(csrf_field()); ?>

                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" list="talukas" type="text" name="taluka" id="taluka">

                            <datalist id="talukas">
                                <?php $__currentLoopData = $trecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trecord->name); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>
                            <label class="mdl-textfield__label" for="taluka">Address(Taluka)</label>
                        </div>

                        </p>

                    </form>
                </div>
                <div class="mdl-dialog__actions">
                    <button id="modal_add" type="button" class="mdl-button">Add</button>
                    <button id="modal_cancel" type="button" class="mdl-button close">Cancel</button>
                </div>
            </dialog>

        </main>
    </div>

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script>
        $('#show-dialog').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.showModal();
        });

        $('#modal_add').click(function () {
            document.getElementById('allocate_form').submit();
        });


        $('#modal_cancel').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.close();
        });


    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>