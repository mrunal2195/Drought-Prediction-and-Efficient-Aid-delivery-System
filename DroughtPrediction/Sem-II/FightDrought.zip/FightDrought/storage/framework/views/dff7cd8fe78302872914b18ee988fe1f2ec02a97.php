<?php $__env->startSection('content'); ?>


    <div class="container" style="margin: 50px auto 50px auto;">
        <form action="/aid/get" method="GET">
            <?php echo e(csrf_field()); ?>

            ID <input type="text" name="id">
            <input type="submit" value="Submit"/>
        </form>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>