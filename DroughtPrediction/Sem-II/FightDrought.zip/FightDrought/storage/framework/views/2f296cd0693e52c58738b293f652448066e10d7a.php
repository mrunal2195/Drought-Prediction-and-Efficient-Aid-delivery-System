<?php $__env->startSection('content'); ?>


    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
        <header class="mdl-layout__header mdl-layout__header--scroll" style="background-color: #303F9F ">

            <div class="mdl-layout__header-row">
                <!-- Title -->
                <span class="mdl-layout-title">Drought Prediction</span>
                <!-- Add spacer, to align navigation to the right -->
                <div class="mdl-layout-spacer"></div>
                <!-- Navigation. We hide it in small screens. -->

            </div>
        </header>


        <main class="mdl-layout__content" style="background-color: #E8EAF6">
            <div class="page-content">


                <style>
                    .demo-card-square.mdl-card {
                        width: 500px;
                        height: 500px;
                    }

                    .demo-card-square > .mdl-card__title {
                        color: #fff;
                        background: url('../images/topbanner.jpg') bottom right 15% no-repeat #46B6AC;
                    }
                </style>

                
                <div class="demo-card-square mdl-card mdl-shadow--2dp" style="margin: 50px auto 100px auto;">
                    <div class="mdl-card__title mdl-card--expand">
                        <h2 class="mdl-card__title-text">Input Parameters</h2>
                    </div>
                    <div class="mdl-card__supporting-text">


                        

                        <div style="width:100%" class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" list="a1" type="text" name="arg1" id="arg1">
                            <label class="mdl-textfield__label" for="arg1">Post Monsoon Water Depth Level</label>

                            <datalist id="a1">
                                <?php $__currentLoopData = $drecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($record->post_monsoon_water_level_depth); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>

                        </div>

                        <div style="width:100%" class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" list="a2" name="arg2" type="text" id="arg2">
                            <label class="mdl-textfield__label" for="arg2">Average Monsoon Rainfall</label>

                            <datalist id="a2">
                                <?php $__currentLoopData = $rrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($record->avg_monsoon_rainfall); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>

                        </div>

                        <div style="width:100%" class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" list="a3" name="arg3" type="text" id="arg3">
                            <label class="mdl-textfield__label" for="arg3">Population</label>

                            <datalist id="a3">
                                <?php $__currentLoopData = $precords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($record->population); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>

                        </div>

                        <!-- MDL Progress Bar with Indeterminate Progress -->
                        <div id="p2" style="display: none"
                             class="mdl-progress mdl-js-progress mdl-progress__indeterminate"></div>


                    </div>
                    <div class="mdl-card__actions mdl-card--border">
                        <a id="predict"
                           class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect mdl-button--accent">
                            Predict
                        </a>

                    </div>
                </div>
            </div>


            <div id="mysnackbar" aria-live="assertive" aria-atomic="true" aria-relevant="text"
                 class="mdl-snackbar mdl-js-snackbar">
                <div class="mdl-snackbar__text"></div>
                <button type="button" class="mdl-snackbar__action"></button>
            </div>


        </main>

    </div>



    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script>


        $('#predict').click(function () {

            $('#p2').show();
            var arg1 = $('#arg1').val();
            var arg2 = $('#arg2').val();
            var arg3 = $('#arg3').val();

            $.ajax({
                url: "http://predictdrought.azurewebsites.net/DroughtPrediction/PredictDrought",
                type: "get",
                data: {
                    arg1: arg1,
                    arg2: arg2,
                    arg3: arg3
                },
                success: function (data, textStatus, jqXHR) {

                    $('#p2').hide();
                    var notification = document.querySelector('#mysnackbar');
                    notification.MaterialSnackbar.showSnackbar(
                        {
                            message: data
                        }
                    );
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }
            });


        });


    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>