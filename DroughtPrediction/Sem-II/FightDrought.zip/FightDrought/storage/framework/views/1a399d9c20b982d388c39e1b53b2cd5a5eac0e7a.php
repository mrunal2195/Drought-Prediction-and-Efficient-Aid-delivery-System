<?php $__env->startSection('content'); ?>

    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
        <header class="mdl-layout__header" style="background-color: #303F9F">
            <div class="mdl-layout__header-row">
                <!-- Title -->
                <span class="mdl-layout-title">Dataset Management</span>
                <!-- Add spacer, to align navigation to the right -->
                <div class="mdl-layout-spacer"></div>
                <!-- Navigation. We hide it in small screens. -->
            </div>
        </header>


        <main class="mdl-layout__content" style="background-color: #E8EAF6">
            <div class="page-content">

                <button id="show-dialog" style="position: fixed;
    display: block;
    right: 0;
    bottom: 0;
    margin-right: 40px;
    margin-bottom: 40px;
    z-index: 900;"
                        class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored">
                    <i class="material-icons">add</i>
                </button>

                <table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp"
                       style="margin:50px auto 50px auto;">


                    <thead>
                    <tr>
                        <th class="mdl-data-table__header--sorted-ascending">ID</th>
                        <th class="mdl-data-table__cell--non-numeric">Taluka Name</th>
                        <th class="mdl-data-table__cell--non-numeric">Population</th>
                        <th class="mdl-data-table__cell--non-numeric">Average Monsoon Rainfall</th>
                        <th class="mdl-data-table__cell--non-numeric">Post Monsoon Water Level Depth</th>
                        <th class="mdl-data-table__cell--non-numeric">Class</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($record->id); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->name); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->population); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->avg_monsoon_rainfall); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->post_monsoon_water_level_depth); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($record->class); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <dialog class="mdl-dialog" style="position:absolute; width:75%;">
                <h4 class="mdl-dialog__title">Add a record</h4>
                <div class="mdl-dialog__content">

                    <form id="dataset_form" action="/dataset/add" method="POST">

                        <?php echo e(csrf_field()); ?>


                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" name="taluka_name" id="taluka_name">
                            <label class="mdl-textfield__label" for="taluka_name">Taluka Name</label>
                        </div>
                        </p>

                        <p>
                        <h6>Population</h6>
                        </p>

                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="population_min" id="population_min">
                            <label class="mdl-textfield__label" for="population_min">Population_Min</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>

                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="population_max" id="population_max">
                            <label class="mdl-textfield__label" for="population_max">Population_Max</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>
                        </p>

                        <p>
                        <h6>Average Rainfall</h6>
                        </p>


                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="rainfall_min" id="rainfall_min">
                            <label class="mdl-textfield__label" for="rainfall_min">Rainfall_Min</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>

                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="rainfall_max" id="rainfall_max">
                            <label class="mdl-textfield__label" for="rainfall_max">Rainfall_Max</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>
                        </p>


                        <p>
                        <h6>Water Depth Level</h6>
                        </p>

                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="water_depth_min" id="water_depth_min">
                            <label class="mdl-textfield__label" for="water_depth_min">WaterDepth_Min</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>

                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="water_depth_max" id="water_depth_max">
                            <label class="mdl-textfield__label" for="water_depth_max">WaterDepth_Max</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>


                        </p>


                        </p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" list="my_list"
                                   name="class" id="class">

                            <datalist id="my_list">
                                <option value="Affected"/>
                                <option value="Not Affected"/>

                            </datalist>

                            <label class="mdl-textfield__label" for="class">Class</label>
                        </div>
                        <p>


                    </form>
                </div>

                <div class="mdl-dialog__actions">
                    <button id="modal_add" type="button" class="mdl-button">Add</button>
                    <button id="modal_cancel" type="button" class="mdl-button close">Cancel</button>
                </div>


            </dialog>


        </main>
    </div>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script>
        $('#show-dialog').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.showModal();
        });

        $('#modal_add').click(function () {
            document.getElementById('dataset_form').submit();
        });


        $('#modal_cancel').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.close();
        });


        $('#show-dialog').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.showModal();
        });


    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>