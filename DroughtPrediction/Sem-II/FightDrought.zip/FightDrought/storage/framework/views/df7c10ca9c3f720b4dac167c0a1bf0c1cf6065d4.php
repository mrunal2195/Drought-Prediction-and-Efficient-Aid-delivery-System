<?php $__env->startSection('content'); ?>

    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
        <header class="mdl-lageyout__header" style="background-color: #303F9F ">

            <div class="mdl-layout__header-row">
                <!-- Title -->
                <span class="mdl-layout-title" style="color:#ffffff;">Home</span>
                <!-- Add spacer, to align navigation to the right -->
                <div class="mdl-layout-spacer"></div>
                <!-- Navigation. We hide it in small screens. -->
            </div>
        </header>


        <main class="mdl-layout__content" style="background-color: #E8EAF6">
            <div class="page-content">
                <div class="demo-card-square mdl-card mdl-shadow--2dp" style="width:100%;">

                    <div style="text-align:center;">
                        <h4>Welcome to Fight Drought!</h4>

                    </div>
                </div>


            </div>
        </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>