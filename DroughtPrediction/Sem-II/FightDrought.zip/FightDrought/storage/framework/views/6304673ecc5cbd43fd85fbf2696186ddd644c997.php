<?php $__env->startSection('content'); ?>


    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
        <header class="mdl-layout__header mdl-layout__header--scroll" style="background-color: #303F9F ">

            <div class="mdl-layout__header-row">
                <!-- Title -->
                <span class="mdl-layout-title">People</span>
                <!-- Add spacer, to align navigation to the right -->
                <div class="mdl-layout-spacer"></div>
                <!-- Navigation. We hide it in small screens.
                <nav class="mdl-navigation">
                    <a id="delete" class="mdl-navigation__link"><i
                                class="material-icons">delete</i></a>
                </nav>
                -->
            </div>
        </header>


        <main class="mdl-layout__content" style="background-color: #E8EAF6">
            <div class="page-content">


                <table class="mdl-data-table mdl-js-data-table mdl-data-table--selectable mdl-shadow--2dp"
                       style="margin: 50px auto 50px auto;">

                    <thead>
                    <tr>
                        <th>ID</th>
                        <th class="mdl-data-table__cell--non-numeric">Family Head Name</th>
                        <th>Age</th>
                        <th class="mdl-data-table__cell--non-numeric">Taluka</th>
                        <th>No. of adults</th>
                        <th>No. of non adults</th>
                    </tr>
                    </thead>
                    <tbody id="table_body">
                    <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($family->id); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($family->headName); ?></td>
                            <td><?php echo e($family->headAge); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($family->talukaName); ?></td>
                            <td><?php echo e($family->adults); ?></td>
                            <td><?php echo e($family->nonAdults); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


            </div>


            <button id="show-dialog" style="position: fixed;
    display: block;
    right: 0;
    bottom: 0;
    margin-right: 40px;
    margin-bottom: 40px;
    z-index: 900;"
                    class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored">
                <i class="material-icons">add</i>
            </button>


            <dialog class="mdl-dialog" style="position:absolute; width:75%;">
                <h4 class="mdl-dialog__title">Add a family</h4>
                <div class="mdl-dialog__content">

                    <form id="people_form" action="/people/add" method="POST">

                        <?php echo e(csrf_field()); ?>


                        <p>


                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="family_id" id="family_id">
                            <label class="mdl-textfield__label" for="family_id">ID</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>
                        </p>
                        <p>
                        <h6>Family head information</h6>
                        </p>

                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" name="head_name" id="head_name">
                            <label class="mdl-textfield__label" for="head_name">Name</label>
                        </div>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="head_age" id="head_age">
                            <label class="mdl-textfield__label" for="head_age">Age</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>

                        </p>

                        <p>
                        <h6>Family information</h6>
                        </p>

                        <p>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?" name="adults"
                                   id="adults">
                            <label class="mdl-textfield__label" for="adults">No. of adults</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?"
                                   name="non_adults" id="non_adults">
                            <label class="mdl-textfield__label" for="non_adults">No. of non-adults</label>
                            <span class="mdl-textfield__error">Input is not a number!</span>
                        </div>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                            <input class="mdl-textfield__input" list="talukas" type="text" name="taluka" id="taluka">

                            <datalist id="talukas">
                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($record->name); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>
                            <label class="mdl-textfield__label" for="taluka">Address(Taluka)</label>
                        </div>

                        </p>
                    </form>

                </div>
                <div class="mdl-dialog__actions">
                    <button id="modal_add" type="button" class="mdl-button">Add</button>
                    <button id="modal_cancel" type="button" class="mdl-button close">Cancel</button>
                </div>
            </dialog>


            <div id="mysnackbar" aria-live="assertive" aria-atomic="true" aria-relevant="text"
                 class="mdl-snackbar mdl-js-snackbar">
                <div class="mdl-snackbar__text"></div>
                <button type="button" class="mdl-snackbar__action"></button>
            </div>

        </main>
    </div>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script>
        $('#show-dialog').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.showModal();
        });

        $('#modal_add').click(function () {
            document.getElementById('people_form').submit();
        });


        $('#delete').click(function () {


        });

        $('#modal_cancel').click(function () {
            var dialog = document.querySelector('dialog');
            if (!dialog.showModal) {
                dialogPolyfill.registerDialog(dialog);
            }
            dialog.close();
        });


    </script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>