<!doctype html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <link rel="stylesheet" type="text/css" href="dialog-polyfill.css"/>

    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>


    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">


    <meta name="theme-color" content="#3F51B5">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Document</title>
</head>
<body>

<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">

    <header class="mdl-layout__header" style="background-color: #3F51B5">
        <div class="mdl-layout__header-row">
            <!-- Title -->
            <span class="mdl-layout-title">Fight Drought</span>

            <!-- Add spacer, to align navigation to the right -->
            <div class="mdl-layout-spacer"></div>
            <!-- Navigation. We hide it in small screens. -->
            <!-- Right aligned menu below button -->
            <div id="demo-menu-lower-right" class="mdl-list__item">
        <span class="mdl-list__item-primary-content">
      <i class="material-icons mdl-list__item-avatar">person</i>

    </span>
            </div>


            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                for="demo-menu-lower-right">

                <li class="mdl-menu__item" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a>
                </li>
            </ul>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>

        </div>
    </header>

    <div class="mdl-layout__drawer">
        <nav class="mdl-navigation">
            <a href="/home" class="mdl-navigation__link" href="">Home</a>
            <a href="/prediction" class="mdl-navigation__link" href="">Drought Prediction</a>
            <a href="/dataset" class="mdl-navigation__link" href="">Dataset Management</a>
            <a href="/people" class="mdl-navigation__link" href="">People</a>
            <a href="/aid" class="mdl-navigation__link" href="">Aid Allocation</a>
        </nav>
    </div>

    <main class="mdl-layout__content">
        <div class="page-content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>


</body>
</html>