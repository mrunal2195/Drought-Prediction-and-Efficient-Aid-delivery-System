<?php

namespace App\Http\Controllers;

use App\Aid;
use App\People;
use Illuminate\Http\Request;
use App\Dataset;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class PeopleController extends Controller
{
    public function store(Request $request)
    {

        $this->validate($request, [
            'family_id' => 'required',
            'head_name' => 'required',
            'head_age' => 'required',
            'taluka' => 'required',
            'adults' => 'required',
            'non_adults' => 'required'
        ]);

        $people = new People;
        $people->id = $request['family_id'];
        $people->headName = $request['head_name'];
        $people->headAge = $request['head_age'];
        $people->talukaName = $request['taluka'];
        $people->adults = $request['adults'];
        $people->nonAdults = $request['non_adults'];
        $people->save();

        $aid = new Aid;
        $aid->family_id = $request['family_id'];
        $aid->headName = $request['head_name'];
        $aid->units = 0;
        //$aid->units = $request['adults'] + $request['non_adults'];
        $aid->deliveryStatus = 'Not Delivered';
        $aid->save();

        return redirect('/people');
    }


    public function index()
    {
        if (Auth::guest()) {
            return redirect('/login');
        } else {
            $families = People::all();
            $records = Dataset::all();
            return view('people', compact('families', 'records'));
        }
    }

    public function destroy()
    {
        People::destroy(Input::get('id'));
        Aid::where('family_id', Input::get('id'))->delete();
        return redirect('/people');
    }
}
