<?php

namespace App\Http\Controllers;

use App\Aid;
use App\Dataset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;


class AidController extends Controller
{
    public function index()
    {
        if (Auth::guest()) {

            return redirect('/login');
        } else {
            $records = Aid::all();
            $trecords = Dataset::all();
            return view('aid', compact('records', 'trecords'));
        }
    }

    public function allocate()
    {
        $taluka = Input::get('taluka');
        $precords = \App\People::where('talukaName', $taluka)->get();
        foreach ($precords as $record) {
            Aid::where('family_id', $record->id)->update(['units' => $record->adults + $record->nonAdults, 'deliveryStatus' => 'Not Delivered']);
        }
        return redirect('/aid');
    }

    public function get()
    {
        $id = Input::get('id');
        $aid = Aid::where('family_id', '=', $id)->get()->first();
        $response = '{"units":' . $aid->units . ',"headName":"' . $aid->headName . '","deliveryStatus":"' . $aid->deliveryStatus . '"}';
        $aid->deliveryStatus = 'Delivered';
        $aid->save();
        return $response;
    }
}
