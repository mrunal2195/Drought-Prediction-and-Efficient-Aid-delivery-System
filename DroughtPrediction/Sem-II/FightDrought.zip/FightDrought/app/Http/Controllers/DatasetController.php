<?php

namespace App\Http\Controllers;

use App\Dataset;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class DatasetController extends Controller
{


    public function index()
    {
        if (Auth::guest()) {
            return view('auth.login');
        } else {
            $records = \App\Dataset::all();
            return view('dataset', compact('records'));
        }


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request, [
            'taluka_name' => 'required',
            'population_min' => 'required',
            'population_max' => 'required',
            'rainfall_min' => 'required',
            'rainfall_max' => 'required',
            'water_depth_min' => 'required',
            'water_depth_max' => 'required'

        ]);

        $record = new Dataset();
        $record->name = $request['taluka_name'];
        $record->population = $request['population_min'] . '-' . $request['population_max'];
        $record->avg_monsoon_rainfall = $request['rainfall_min'] . '-' . $request['rainfall_max'];
        $record->post_monsoon_water_level_depth = $request['water_depth_min'] . '-' . $request['water_depth_max'];
        $record->class = $request['class'];
        $record->save();

        return redirect('/dataset');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Dataset $dataset
     * @return \Illuminate\Http\Response
     */
    public function show(Dataset $dataset)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Dataset $dataset
     * @return \Illuminate\Http\Response
     */
    public function edit(Dataset $dataset)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Dataset $dataset
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Dataset $dataset)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Dataset $dataset
     * @return \Illuminate\Http\Response
     */
    public function destroy(Dataset $dataset)
    {
        //
        Dataset::destroy(Input::get('id'));
        return redirect('/dataset');
    }
}
